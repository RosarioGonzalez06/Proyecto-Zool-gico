package cargo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import CRUD.CRUD;


public class CargoService implements CRUD<Cargo>{

    Connection conn;
    public CargoService(Connection conn){
        this.conn = conn;
    }

    public void exportToCSV(String file) throws Exception {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));
            ArrayList<Cargo> cargos = this.requestAll();
            for(Cargo car:cargos){
                bw.write(car.serialize()+"\n");
            }
            bw.close();
        } catch(IOException e){
            throw new Exception("Ocurrión un error de E/S "+ e.toString());
        } catch(SQLException e){
            throw new Exception("Ocurrión un error al acceder a la base de datos "+ e.toString());
        }catch (Exception e) {
            throw new Exception("Ocurrión un error "+ e.toString());
        } finally {
            if(bw!=null)
                bw.close();
        }
    }

    @Override
    public ArrayList<Cargo> requestAll() throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        ArrayList<Cargo> res= new ArrayList<Cargo>();
        statement = this.conn.createStatement();   
        String sql = "SELECT codCar, nomcar FROM cargo";
        ResultSet querySet = statement.executeQuery(sql);
        while(querySet.next()) {
            Integer codCar = querySet.getInt("codcar");
            String nomCar = querySet.getString("nomCar");
            res.add(new Cargo(codCar, nomCar));
        } 
        statement.close();    
        return res;
    }

    @Override
    public Integer create (Cargo object) throws SQLException {
        // TODO Auto-generated method stub
        String sqlaux = String.format("INSERT INTO cargo (nomCar) VALUES (?)");
        PreparedStatement prepst = this.conn.prepareStatement(sqlaux, Statement.RETURN_GENERATED_KEYS);
        prepst.setString(1, object.getnomCar());
        prepst.execute();
        ResultSet keys = prepst.getGeneratedKeys();
        if(keys.next()){
            Integer codCar = keys.getInt(1);
                prepst.close();
                return codCar;
        }
        else{
            throw new SQLException("Creating species failed, no rows affected.");
        }
        
    }

    @Override
    public boolean delete(Integer codCar) throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("DELETE FROM cargo WHERE codCar=%d", codCar);
        int res = statement.executeUpdate(sql);
        statement.close();
        return res==1;
    }
    
}
