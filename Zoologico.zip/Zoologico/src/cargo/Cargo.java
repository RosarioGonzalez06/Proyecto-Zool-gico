package cargo;


public class Cargo {
    Integer codCar;
    String nomCar;

    public Cargo(Integer codCar,String nomCar) {
        this.codCar = codCar;
        this.nomCar = nomCar;
    }

    public Cargo() {
        this(0,"");
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return String.format("ID: %d, nombre: %s", this.codCar, this.nomCar);
    }

    public String serialize() {
            return String.format("\"%d\";\"%s\"", codCar, nomCar != null ? nomCar : "");
        
    }

    public Integer getCodCar() {
        return codCar;
    }

    public void setCodCar(Integer codCar) {
        this.codCar = codCar;
    }

    public String getnomCar() {
        return nomCar;
    }

    public void setnomCar(String nomCar) {
        this.nomCar = nomCar;
    }

}
