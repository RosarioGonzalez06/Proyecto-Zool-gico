package cuidador;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;

import CRUD.CRUD;

public class CuidadorService implements CRUD<Cuidador>{

    Connection conn;
    public CuidadorService(Connection conn){
        this.conn = conn;
    }

    public void exportToCSV(String file) throws Exception {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));
            ArrayList<Cuidador> cuidadores = this.requestAll();
            for(Cuidador cui:cuidadores){
                bw.write(cui.serialize()+"\n");
            }
            bw.close();
        } catch(IOException e){
            throw new Exception("Ocurrión un error de E/S "+ e.toString());
        } catch(SQLException e){
            throw new Exception("Ocurrión un error al acceder a la base de datos "+ e.toString());
        }catch (Exception e) {
            throw new Exception("Ocurrión un error "+ e.toString());
        } finally {
            if(bw!=null)
                bw.close();
        }
    }

    @Override
    public ArrayList<Cuidador> requestAll() throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        ArrayList<Cuidador> res = new ArrayList<Cuidador>();
        statement = this.conn.createStatement();   
        try {
        String sql = "SELECT codCui, nomCui, apeCui, fecNacCui, telCui, fecIng, codCar FROM cuidador";
        ResultSet querySet = statement.executeQuery(sql);
        while(querySet.next()) {
            Integer codCui = querySet.getInt("codCui");
            String nomCui = querySet.getString("nomCui");
            String apeCui = querySet.getString("apeCui");
            Date fecNacCui = querySet.getDate("fecNacCui");
            String telCui = querySet.getString("telCui");
            Date fecIng = querySet.getDate("fecIng");
            Integer codCar = querySet.getInt("codCar")==0?null:querySet.getInt("codCar");
            res.add(new Cuidador(codCui, nomCui, apeCui, fecNacCui, telCui, fecIng,codCar));
        } 
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
        statement.close();    
        return res;
    }

    public Cuidador requestByNomApe(String nomCui, String apeCui) throws SQLException {
        Statement statement = null;
        Cuidador res = null;
        statement = this.conn.createStatement();    
        String sql = String.format(
            "SELECT codCui, nomCui, apeCui, fecNacCui, telCui, fecIng, codCar FROM cuidador WHERE nomCui='%s' AND apeCui='%s'",
            nomCui, apeCui
        );
        ResultSet querySet = statement.executeQuery(sql);
    
        if(querySet.next()) {
            Integer codCui = querySet.getInt("codCui");
            Date fecNacCui = querySet.getDate("fecNacCui");
            String telCui = querySet.getString("telCui");
            Date fecIng = querySet.getDate("fecIng");
            Integer codCar = querySet.getInt("codCar")==0?null:querySet.getInt("codCar");
    
            res = new Cuidador(codCui, nomCui, apeCui, fecNacCui, telCui, fecIng,codCar);
        }
    
        statement.close();    
        return res;
    }
    

    @Override
    public Integer create(Cuidador object) throws SQLException {
        // TODO Auto-generated method stub
        String sqlaux = String.format("INSERT INTO cuidador (nomCui, apeCui, fecNacCui, telCui, fecIng, codCar ) VALUES (?, ?, ?, ?, ?, ?)");
        PreparedStatement prepst = this.conn.prepareStatement(sqlaux, Statement.RETURN_GENERATED_KEYS);
        prepst.setString(1, object.getNomCui());
        prepst.setString(2, object.getApeCui());
        prepst.setDate(3, object.getFecNacCui());
        prepst.setString(4, object.getTelCui());
        prepst.setDate(5, object.getFecIng());
        if(object.getcodCar()==null)
            prepst.setNull(6,Types.INTEGER);
        else
            prepst.setInt(6, object.getcodCar());
        prepst.execute();
        ResultSet keys = prepst.getGeneratedKeys();
        if(keys.next()){
            Integer codCui = keys.getInt(1);
                prepst.close();
                return codCui;
        }
        else{
            throw new SQLException("Creating carer failed, no rows affected.");
        }
    }

    public int update(Cuidador object) throws SQLException {
        Integer codCui = object.getCodCui();
        String nomCui = object.getNomCui();
        String apeCui = object.getApeCui();
        Date fecNacCui = object.getFecNacCui();
        String telCui = object.getTelCui();
        Date fecIng = object.getFecIng();
        Integer codCar = object.getcodCar();
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("UPDATE cuidador SET nomCui = '%s', apeCui = '%s', fecNacCui = '%s', telCui = '%s', fecIng = '%s', codCar=%d  WHERE codCui=%d", nomCui, apeCui,fecNacCui,telCui,fecIng, codCar, codCui);
        int affectedRows = statement.executeUpdate(sql);
        statement.close();
        if (affectedRows == 0)
            throw new SQLException("Creating carer failed, no rows affected.");
        else
            return affectedRows;
    }

    @Override
    public boolean delete(Integer codCui) throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("DELETE FROM cuidador WHERE codCui=%d", codCui);
        int res = statement.executeUpdate(sql);
        statement.close();
        return res==1;
    }
    
}
