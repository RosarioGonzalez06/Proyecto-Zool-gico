package cuidador;

import java.sql.Date;

import cuidador.Cuidador;

public class Cuidador {
    Integer codCui;
    String nomCui;
    String apeCui;
    Date fecNacCui;
    String telCui;
    Date fecIng;
    Integer codCar;
    

    public Cuidador(Integer codCui, String nomCui, String apeCui, Date fecNacCui, String telCui,Date fecIng, Integer codCar) {
        this.codCui = codCui;
        this.nomCui = nomCui;
        this.apeCui = apeCui;
        this.fecNacCui = fecNacCui;
        this.telCui = telCui;
        this.fecIng = fecIng;
        this.codCar=codCar;
    }

    public Cuidador() {
        this(0,"","",null,"",null,0);
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return String.format("ID: %d, Nombre: %s, Apellido: %s, Fecha de nacimiento: %s, Telefono: %s, Fecha ingreso: %s, codCar: %d", this.codCui, this.nomCui, this.apeCui,this.fecNacCui,this.telCui,this.fecIng,codCar);
    }

    public String serialize() {
            return String.format("\"%d\";\"%s\";\"%s\";\"%s\";\"%s\";\"%s\";\"%d\"",codCui, nomCui != null ? nomCui : "", apeCui != null ? apeCui : "", fecNacCui != null ? new java.text.SimpleDateFormat("dd-MM-yyyy").format(fecNacCui) : "", telCui != null ? telCui : "", fecIng != null ? new java.text.SimpleDateFormat("dd-MM-yyyy").format(fecIng) : "",codCar);   
    }

    public Integer getCodCui() {
        return codCui;
    }

    public void setCodCui(Integer codCui) {
        this.codCui = codCui;
    }

    public String getNomCui() {
        return nomCui;
    }

    public void setNomCui(String nomCui) {
        this.nomCui = nomCui;
    }

    public String getApeCui() {
        return apeCui;
    }

    public void setApeCui(String apeCui) {
        this.apeCui = apeCui;
    }

    public Date getFecNacCui() {
        return fecNacCui;
    }

    public void setFecNacCui(Date fecNacCui) {
        this.fecNacCui = fecNacCui;
    }

    public Integer getcodCar() {
        return codCar;
    }

    public void setcodCar(Integer codCar) {
        this.codCar = codCar;
    }

    public String getTelCui() {
        return telCui;
    }

    public void setTelCui(String telCui) {
        this.telCui = telCui;
    }

    public Date getFecIng() {
        return fecIng;
    }

    public void setFecIng(Date fecIng) {
        this.fecIng = fecIng;
    }
}
