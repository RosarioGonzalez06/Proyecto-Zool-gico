import java.io.File;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import alimento.Alimento;
import alimento.AlimentoService;
import animal.Animal;
import animal.AnimalService;
import animal.Sexo;
import cargo.Cargo;
import cargo.CargoService;
import come.ComeService;
import connection.ConnectionPool;
import cuida.CuidaService;
import cuidador.Cuidador;
import cuidador.CuidadorService;
import especie.Especie;
import especie.EspecieService;
import recinto.Recinto;
import recinto.RecintoService;

public class App {

    public static void listarAlimentos(AlimentoService service) {
        try {
            ArrayList<Alimento> alimentos = service.requestAll();
            if (alimentos.size() == 0) {
                System.out.println("No hay alimentos");
            } else {
                for (Alimento al : alimentos) {
                    System.out.println(al);
                }
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void listarAnimal(AnimalService service) {

        try {
            ArrayList<Animal> animales = service.requestAll();
            if (animales.size() == 0) {
                System.out.println("No hay animales");
            } else {
                for (Animal an : animales) {
                    System.out.println(an);
                }
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void listarAnimalByNom(AnimalService service) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Ingrese el nombre del animal: ");
            String nomAni = scanner.nextLine();

            Animal animal = service.requestByNom(nomAni);

            if (animal == null) {
                System.out.println("No se encontró ningún animal con el nombre: " + nomAni);
            } else {
                System.out.println(animal);
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar el animal.");
            e.printStackTrace();
        }
    }

    public static void listarCuidador(CuidadorService service) {
        try {
            ArrayList<Cuidador> cuidadores = service.requestAll();
            if (cuidadores.size() == 0) {
                System.out.println("No hay cuidadores");
            } else {
                for (Cuidador cui : cuidadores) {
                    System.out.println(cui);
                }
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void listarCuidadorByNomApe(CuidadorService service) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Ingrese el nombre del Cuidador: ");
            String nomCui = scanner.nextLine();
            System.out.print("Ingrese el apellido del Cuidador: ");
            String apeCui = scanner.nextLine();

            Cuidador cuidador = service.requestByNomApe(nomCui, apeCui);

            if (cuidador == null) {
                System.out.println("No se encontró ningún cuidador con el nombre y apellido: " + nomCui + " " + apeCui);
            } else {
                System.out.println(cuidador);
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar el cuidador.");
            e.printStackTrace();
        }
    }

    public static void listarRecinto(RecintoService service) {
        try {
            ArrayList<Recinto> recintos = service.requestAll();
            if (recintos.size() == 0) {
                System.out.println("No hay recintos");
            } else {
                for (Recinto rec : recintos) {
                    System.out.println(rec);
                }
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void listarCargo(CargoService service) {
        try {
            ArrayList<Cargo> cargos = service.requestAll();
            if (cargos.size() == 0) {
                System.out.println("No hay cargos");
            } else {
                for (Cargo car : cargos) {
                    System.out.println(car);
                }
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void listarRecintoByNom(RecintoService service) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Ingrese el nombre del recinto: ");
            String nomRec = scanner.nextLine();

            Recinto recinto = service.requestByNom(nomRec);

            if (recinto == null) {
                System.out.println("No se encontró ningún recinto con el nombre: " + nomRec);
            } else {
                System.out.println(recinto);
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar el recinto.");
            e.printStackTrace();
        }
    }

    public static void listarEspecie(EspecieService service) {
        try {
            ArrayList<Especie> especies = service.requestAll();
            if (especies.size() == 0) {
                System.out.println("No hay especies");
            } else {
                for (Especie esp : especies) {
                    System.out.println(esp);
                }
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void listarEspecieByTip(EspecieService service) {

        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Ingrese el tipo de especie: ");
            String tipEsp = scanner.nextLine();

            Especie especie = service.requestByNom(tipEsp);

            if (especie == null) {
                System.out.println("No se encontró ningúna especie del tipo: " + tipEsp);
            } else {
                System.out.println(especie);
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar el recinto.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        // Configuración de la conexión a la base de datos
        String url = "jdbc:mysql://localhost:3306/zoo";
        String usuario = "RosarioZoo";
        String clave = "12345";

        ConnectionPool pool = new ConnectionPool(url, usuario, clave);
        AnimalService anservice = new AnimalService(pool.getConnection());
        CuidadorService cuiservice = new CuidadorService(pool.getConnection());
        RecintoService recservice = new RecintoService(pool.getConnection());
        EspecieService espservice = new EspecieService(pool.getConnection());
        AlimentoService alservice = new AlimentoService(pool.getConnection());
        ComeService comservice = new ComeService(pool.getConnection());
        CuidaService cuidService = new CuidaService(pool.getConnection());
        CargoService carService = new CargoService(pool.getConnection());

        String nomAni = "", nomCui = "", apeCui = "", telCui = "", nomRec = "", desRec = "", tipEsp = "",
                desEsp = "", nomAli = "", nomCar = "";
        Integer codAni = null, codEsp = null, codRec = null, codCui = null, codAli = null, codCar = null;
        Sexo sexAni = null;
        Date fecNac = null, fecNacCui = null, fecIng = null;

        boolean salir = false;

        while (!salir) {
            try {
                System.out.println("-------------------------------");
                System.out.println("|  ____      _____     _____  |");
                System.out.println("|     /     |     |   |     | |");
                System.out.println("|    /      |     |   |     | |");
                System.out.println("|   /____   |_____|   |_____| |");
                System.out.println("-------------------------------");
                System.out.println("1. Registro de animales");
                System.out.println("2. Registro de cuidadores");
                System.out.println("3. Registrar cargos");
                System.out.println("4. Registro de recintos");
                System.out.println("5. Registro de especies");
                System.out.println("6. Alimentación");
                System.out.println("7. Eliminar fichero");
                System.out.println("8. Salir");

                int opcion = Integer.parseInt(sc.nextLine());
                Statement statement = null;
                statement = anservice.conn.createStatement();
                switch (opcion) {
                    case 1:
                        boolean submenusalir = false;
                        while (!submenusalir) {
                            try {
                                System.out.println("1. Registrar un nuevo animal");
                                System.out.println("2. Modificar la información de un animal");
                                System.out.println("3. Consultar la lista de animales");
                                System.out.println("4. Consultar animal por su nombre");
                                System.out.println("5. Eliminar un animal");
                                System.out.println("6. Crear fichero con la lista de animales disponibles");
                                System.out.println("7. Salir");
                                int opcion1 = Integer.parseInt(sc.nextLine());

                                switch (opcion1) {
                                    case 1:
                                        System.out.println("Introduzca el nombre del animal: ");
                                        nomAni = sc.nextLine();
                                        System.out
                                                .println("Introduzca la fecha de nacimiento (YYYY-MM-DD) del animal: ");
                                        String fecNacAniAux = sc.nextLine();
                                        fecNac = Date.valueOf(fecNacAniAux);
                                        System.out.println("Introduzca el sexo del animal (M/F): ");
                                        String sexAniAux = sc.nextLine().toUpperCase();
                                        sexAni = Sexo.valueOf(sexAniAux);
                                        listarEspecie(espservice);
                                        System.out.println("Introduzca el codigo de la especie del animal: ");
                                        codEsp = Integer.parseInt(sc.nextLine());
                                        listarRecinto(recservice);
                                        System.out.println("Introduzca el codigo del recinto del animal: ");
                                        codRec = Integer.parseInt(sc.nextLine());

                                        try {
                                            codAni = anservice
                                                    .create(new Animal(0, nomAni, fecNac, sexAni, codEsp, codRec));
                                            System.out.printf("Animal registrado correctamente (codAni: %d)\n", codAni);
                                        } catch (SQLException e) {
                                            System.out.println(
                                                    "Introduce los datos correctamente");
                                            if (e.getErrorCode() == 1062) {
                                                System.out.println(
                                                        "Ya hay un animal registrado con ese nombre,intentelo de nuevo con uno diferente.");
                                            }
                                        }
                                        break;

                                    case 2:
                                        System.out.println("Elija el codigo del animal a modificar");
                                        listarAnimal(anservice);
                                        codAni = Integer.parseInt(sc.nextLine());
                                        String sql = String.format("SELECT * FROM animal WHERE codAni=%d", codAni);

                                        ResultSet querySet = statement.executeQuery(sql);
                                        String aux = "";
                                        while (querySet.next()) {
                                            codAni = querySet.getInt("codAni");
                                            nomAni = querySet.getString("nomAni");
                                            fecNac = querySet.getDate("fecNac");
                                            String sexAniStr = querySet.getString("sexAni");
                                            sexAni = Sexo.valueOf(sexAniStr.toUpperCase());
                                            codEsp = querySet.getInt("codEsp") == 0 ? null : querySet.getInt("codEsp");
                                            codRec = querySet.getInt("codRec") == 0 ? null : querySet.getInt("codRec");
                                        }
                                        System.out.println(
                                                "Introduzca el nombre del animal (si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        nomAni = aux.isEmpty() ? nomAni : aux;
                                        System.out.println(
                                                "Introduzca la fecha nacimiento del animal (YYYY-MM-DD)(si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        String fecNacAniAux1 = aux.isEmpty() ? String.valueOf(fecNac) : aux;
                                        fecNac = Date.valueOf(fecNacAniAux1);
                                        System.out.println(
                                                "Introduzca el sexo del animal (M/F)(si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().toUpperCase().trim();
                                        String sexAniAux1 = aux.isEmpty() ? String.valueOf(sexAni) : aux;
                                        sexAni = Sexo.valueOf(sexAniAux1);
                                        listarEspecie(espservice);
                                        System.out.println(
                                                "Introduzca el codigo de la especie del animal(si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        int codEspAux = aux.isEmpty() ? codEsp : Integer.parseInt(aux);
                                        codEsp = codEspAux;
                                        listarRecinto(recservice);
                                        System.out.println(
                                                "Introduzca el codigo del recinto del animal(si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        int codRecAux = aux.isEmpty() ? codRec : Integer.parseInt(aux);
                                        codRec = codRecAux;

                                        try {
                                            int rowAffected = anservice
                                                    .update(new Animal(codAni, nomAni, fecNac, sexAni, codEsp, codRec));
                                            if (rowAffected == 1)
                                                System.out.println("Datos del animal modificados correctamente");
                                            else
                                                System.out.println("No se ha podido modificar los datos del animal");
                                        } catch (SQLException e) {
                                            System.out.println("No se ha podido modificar los datos del animal");
                                            System.out.println("Ocurrión una excepción: " + e.getMessage());
                                        }
                                        break;

                                    case 3:
                                        listarAnimal(anservice);
                                        break;

                                    case 4:
                                        listarAnimalByNom(anservice);
                                        break;

                                    case 5:
                                        System.out.println("Elija el codigo del animal a borrar");
                                        listarAnimal(anservice);
                                        codAni = Integer.parseInt(sc.nextLine());
                                        try {
                                            anservice.delete(codAni);
                                            System.out.println("animal eliminado correctamente");
                                        } catch (SQLException e) {
                                            System.out.println("error: "+e.getMessage());
                                        }
                                        break;

                                    case 6:
                                        System.out.println("Ingrese el nombre del archivo CSV (ejemplo: animal.csv): ");
                                        anservice.exportToCSV(sc.nextLine());
                                        System.out.println("Archivo creado correctamente");
                                        break;

                                    case 7:
                                        submenusalir = true;
                                        break;

                                    default:
                                        break;
                                }
                            } catch (Exception e) {
                                System.out.println("error: "+e.getMessage());
                            }
                        }
                        break;

                    case 2:
                        submenusalir = false;
                        while (!submenusalir) {
                            try {
                                System.out.println("1. Agregar un nuevo cuidador.");
                                System.out.println("2. Actualizar datos de un cuidador");
                                System.out.println("3. Asignar animales a cuidadores");
                                System.out.println("4. Listar cuidador por su nombre y apellido.");
                                System.out.println("5. Listar cuidadores y los animales que cuidan.");
                                System.out.println("6. Eliminar un cuidador");
                                System.out.println("7. Crear fichero con la lista de cuidadores disponibles");
                                System.out.println("8. Salir");
                                int opcion1 = Integer.parseInt(sc.nextLine());

                                switch (opcion1) {
                                    case 1:
                                        System.out.println("Introduzca el nombre del cuidador: ");
                                        nomCui = sc.nextLine();
                                        System.out.println("Introduzca el apellido del cuidador: ");
                                        apeCui = sc.nextLine();
                                        System.out.println(
                                                "Introduzca la fecha de nacimiento del cuidador (YYYY-MM-DD): ");
                                        String fecNacCuiAux = sc.nextLine();
                                        fecNacCui = Date.valueOf(fecNacCuiAux);
                                        System.out.println("Introduzca el teléfono del cuidador: ");
                                        telCui = sc.nextLine();
                                        System.out
                                                .println("Introduzca la fecha de ingreso del cuidador (YYYY-MM-DD): ");
                                        String fecIngAux = sc.nextLine();
                                        fecIng = Date.valueOf(fecIngAux);
                                        listarCargo(carService);
                                        System.out.println("Introduzca el codigo del cargo del cuidador: ");
                                        codCar = Integer.parseInt(sc.nextLine());

                                        try {
                                            codCui = cuiservice.create(
                                                    new Cuidador(0, nomCui, apeCui, fecNacCui, telCui, fecIng, codCar));
                                            System.out.printf("Cuidador registrado correctamente (codCui: %d)\n",
                                                    codCui);
                                        } catch (SQLException e) {
                                            System.out.println(
                                                    "Introduce los datos correctamente asegurandote que el cargo ya exista");
                                            if (e.getErrorCode() == 1062) {
                                                System.out.println(
                                                        "Ya hay un cuidador registrado con ese número de telefono,intentelo de nuevo con uno diferente.");
                                            }

                                        }
                                        break;

                                    case 2:
                                        System.out.println("Elija el cuidador a modificar");
                                        listarCuidador(cuiservice);
                                        codCui = Integer.parseInt(sc.nextLine());
                                        String sql = String.format("SELECT * FROM cuidador WHERE codCui=%d", codCui);

                                        ResultSet querySet = statement.executeQuery(sql);
                                        String aux = "";
                                        while (querySet.next()) {
                                            codCui = querySet.getInt("codCui");
                                            nomCui = querySet.getString("nomCui");
                                            apeCui = querySet.getString("apeCui");
                                            fecNacCui = querySet.getDate("fecNacCui");
                                            telCui = querySet.getString("telCui");
                                            fecIng = querySet.getDate("fecIng");
                                            codCar = querySet.getInt("codCar") == 0 ? null : querySet.getInt("codCar");
                                        }
                                        System.out.println(
                                                "Introduzca el nombre del cuidador (si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        nomCui = aux.isEmpty() ? nomCui : aux;
                                        System.out.println(
                                                "Introduzca el apellido del cuidador (si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        apeCui = aux.isEmpty() ? apeCui : aux;
                                        System.out.println(
                                                "Introduzca la fecha de nacimiento del cuidador (YYYY-MM-DD)(si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        String fecNacCuiAux1 = aux.isEmpty() ? String.valueOf(fecNacCui) : aux;
                                        fecNacCui = Date.valueOf(fecNacCuiAux1);
                                        System.out.println(
                                                "Introduzca el teléfono del cuidador (si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        telCui = aux.isEmpty() ? telCui : aux;
                                        System.out.println(
                                                "Introduzca la fecha de ingreso del cuidador (YYYY-MM-DD) (si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        String fecIngAux1 = aux.isEmpty() ? String.valueOf(fecIng) : aux;
                                        fecIng = Date.valueOf(fecIngAux1);
                                        listarCargo(carService);
                                        System.out.println(
                                                "Introduzca el codigo del cargo del cuidador(si quiere que sea el mismo presiona enter): ");
                                        aux = sc.nextLine().trim();
                                        int codCarAux = aux.isEmpty() ? codCar : Integer.parseInt(aux);
                                        codCar = codCarAux;

                                        try {
                                            int rowAffected = cuiservice
                                                    .update(new Cuidador(codCui, nomCui, apeCui, fecNacCui,
                                                            telCui,
                                                            fecIng, codCar));
                                            if (rowAffected == 1)
                                                System.out.println("Datos del cuidador modificados correctamente");
                                            else
                                                System.out.println("No se ha podido modificar los datos del cuidador");
                                        } catch (SQLException e) {
                                            System.out.println("No se ha podido modificar los datos del cuidador");
                                            System.out.println("Ocurrión una excepción: " + e.getMessage());
                                        }
                                        break;

                                    case 3:
                                        listarCuidador(cuiservice);
                                        System.out.println("Ingrese el código del cuidador:");
                                        codCui = Integer.parseInt(sc.nextLine());

                                        listarAnimal(anservice);
                                        System.out.println("Ingrese el código del animal:");
                                        codAni = Integer.parseInt(sc.nextLine());

                                        sql = String.format(
                                                "INSERT INTO cuida (codCui, codAni) VALUES (%d, %d)", codCui,
                                                codAni);

                                        try {
                                            int rowAffected = statement.executeUpdate(sql);
                                            if (rowAffected == 1) {
                                                System.out.println("Cuidador asignado al animal correctamente.");
                                            } else {
                                                System.out.println("No se pudo asignar el cuidador.");
                                            }
                                        } catch (SQLException e) {
                                            System.out.println("El cuidador ya tiene asignado ese animal");
                                        }
                                        break;

                                    case 4:
                                        listarCuidadorByNomApe(cuiservice);
                                        break;

                                    case 5:
                                        listarCuidador(cuiservice);
                                        System.out.print("Ingrese el codigo del cuidador: ");
                                        codCui = Integer.parseInt(sc.nextLine());

                                        ArrayList<String> cuidan = cuidService.cuidaAnimal(codCui);

                                        if (cuidan.isEmpty()) {
                                            System.out
                                                    .println(" No hay ningún animal que sea cuidado por ese cuidador.");
                                        } else {
                                            System.out.println(
                                                    "Animales que son cuidados por ese cuidador:");
                                            for (String c : cuidan) {
                                                System.out.println(c);
                                            }
                                        }
                                        break;

                                    case 6:
                                        System.out.println("Elija el codigo del cuidador a borrar");
                                        listarCuidador(cuiservice);
                                        codCui = Integer.parseInt(sc.nextLine());
                                        try {
                                            cuiservice.delete(codCui);
                                            System.out.println("Cuidador eliminado correctamente");
                                        } catch (SQLException e) {
                                            System.out.println("error al eliminar");
                                        }
                                        break;

                                    case 7:
                                        System.out
                                                .println("Ingrese el nombre del archivo CSV (ejemplo: cuidador.csv): ");
                                        cuiservice.exportToCSV(sc.nextLine());
                                        System.out.println("Archivo creado correctamente");
                                        break;

                                    case 8:
                                        submenusalir = true;
                                        break;

                                    default:
                                        break;
                                }

                            } catch (Exception e) {
                                System.out.println("error: "+e.getMessage());
                            }
                        }
                        break;

                    case 3:
                        submenusalir = false;
                        while (!submenusalir) {
                            try {
                                System.out.println("1. Registrar un nuevo cargo");
                                System.out.println("2. Listar cargos");
                                System.out.println("3. Eliminar cargo");
                                System.out.println("4. Crear fichero con la lista de cargos disponibles");
                                System.out.println("5. Salir");
                                int opcion1 = Integer.parseInt(sc.nextLine());

                                switch (opcion1) {
                                    case 1:
                                        System.out.println("Introduzca el nombre del cargo: ");
                                        nomCar = sc.nextLine();

                                        try {
                                            codCar = carService
                                                    .create(new Cargo(0, nomCar));
                                            System.out.printf("Cargo registrado correctamente (codCar: %d)\n",
                                                    codCar);
                                        } catch (SQLException e) {
                                            if (e.getErrorCode() == 1062) {
                                                System.out.println(
                                                        "Ya hay un cargo registrado con ese nombre,intentelo de nuevo con uno diferente.");
                                            }
                                        }
                                        break;

                                    case 2:
                                        listarCargo(carService);
                                        break;

                                    case 3:
                                        System.out.println("Elija el codigo del cargo a borrar");
                                        listarCargo(carService);
                                        codCar = Integer.parseInt(sc.nextLine());
                                        try {
                                            carService.delete(codCar);
                                            System.out.println("Cargo borrado exitosamente");
                                        } catch (SQLException e) {
                                            System.out.println("error: "+e.getMessage());
                                        }
                                        break;

                                    case 4:
                                        System.out
                                                .println("Ingrese el nombre del archivo CSV (ejemplo: cargo.csv): ");
                                        carService.exportToCSV(sc.nextLine());
                                        System.out.println("Archivo creado correctamente");
                                        break;

                                    case 5:
                                        submenusalir = true;
                                        break;

                                    default:
                                        break;
                                }
                            } catch (Exception e) {
                                System.out.println("error: "+e.getMessage());
                            }
                        }
                        break;

                    case 4:
                        submenusalir = false;
                        while (!submenusalir) {
                            try {
                                System.out.println("1. Registrar un nuevo recinto");
                                System.out.println("2. Consultar los recintos");
                                System.out.println("3. Consultar recinto por nombre");
                                System.out.println("4. Eliminar recinto");
                                System.out.println("5. Crear fichero con la lista de recintos disponibles");
                                System.out.println("6. Salir");
                                int opcion1 = Integer.parseInt(sc.nextLine());

                                switch (opcion1) {
                                    case 1:
                                        System.out.println("Introduzca el nombre del recinto: ");
                                        nomRec = sc.nextLine();
                                        System.out.println("Introduzca una breve descripcion del recinto: ");
                                        desRec = sc.nextLine();

                                        try {
                                            codRec = recservice
                                                    .create(new Recinto(0, nomRec, desRec));
                                            System.out.printf("Recinto registrado correctamente (codRec: %d)\n",
                                                    codRec);
                                        } catch (SQLException e) {
                                            if (e.getErrorCode() == 1062) {
                                                System.out.println(
                                                        "Ya hay un recinto registrado con ese nombre,intentelo de nuevo con uno diferente.");
                                            }
                                        }
                                        break;

                                    case 2:
                                        listarRecinto(recservice);
                                        break;

                                    case 3:
                                        listarRecintoByNom(recservice);
                                        break;

                                    case 4:
                                        System.out.println("Elija el codigo del recinto a borrar");
                                        listarRecinto(recservice);
                                        codRec = Integer.parseInt(sc.nextLine());
                                        try {
                                            recservice.delete(codRec);
                                            System.out.println("Recinto borrado exitosamente");
                                        } catch (SQLException e) {
                                            System.out.println("error: "+e.getMessage());
                                        }
                                        break;

                                    case 5:
                                        System.out
                                                .println("Ingrese el nombre del archivo CSV (ejemplo: recinto.csv): ");
                                        recservice.exportToCSV(sc.nextLine());
                                        System.out.println("Archivo creado correctamente");
                                        break;

                                    case 6:
                                        submenusalir = true;
                                        break;

                                    default:
                                        break;
                                }
                            } catch (Exception e) {
                                System.out.println("error: "+e.getMessage());
                            }
                        }
                        break;

                    case 5:
                        submenusalir = false;
                        while (!submenusalir) {
                            try {
                                System.out.println("1. Registrar una nueva especie");
                                System.out.println("2. Consultar especie por tipo");
                                System.out.println("3. Consultar todas las especies");
                                System.out.println("4. Eliminar especie");
                                System.out.println("5. Crear fichero con la lista de especies disponibles");
                                System.out.println("6. Salir");
                                int opcion1 = Integer.parseInt(sc.nextLine());

                                switch (opcion1) {
                                    case 1:
                                        System.out.println("Introduzca el nombre de la especie: ");
                                        tipEsp = sc.nextLine();
                                        System.out.println("Introduzca una breve descripcion de la especie: ");
                                        desEsp = sc.nextLine();
                                        try {
                                            codEsp = espservice
                                                    .create(new Especie(0, tipEsp, desEsp));
                                            System.out.printf("Especie registrada correctamente (codEsp: %d)\n",
                                                    codEsp);
                                        } catch (SQLException e) {
                                            if (e.getErrorCode() == 1062) {
                                                System.out.println(
                                                        "Ya hay una especie registrada con ese nombre,intentelo de nuevo con uno diferente.");
                                            }
                                        }
                                        break;

                                    case 2:
                                        listarEspecieByTip(espservice);
                                        break;

                                    case 3:
                                        listarEspecie(espservice);
                                        break;

                                    case 4:
                                        System.out.println("Elija el codigo de la especie a borrar");
                                        listarEspecie(espservice);
                                        codEsp = Integer.parseInt(sc.nextLine());
                                        try {
                                            espservice.delete(codEsp);
                                            System.out.println("Especie borrada exitosamente");
                                        } catch (SQLException e) {
                                            System.out.println("error: "+e.getMessage());
                                        }
                                        break;

                                    case 5:
                                        System.out
                                                .println("Ingrese el nombre del archivo CSV (ejemplo: especie.csv): ");
                                        espservice.exportToCSV(sc.nextLine());
                                        System.out.println("Archivo creado correctamente");
                                        break;

                                    case 6:
                                        submenusalir = true;
                                        break;

                                    default:
                                        break;
                                }
                            } catch (Exception e) {
                                System.out.println("error: "+e.getMessage());
                            }
                        }
                        break;

                    case 6:
                        submenusalir = false;
                        while (!submenusalir) {
                            try {
                                System.out.println("1. Registrar un nuevo alimento");
                                System.out.println("2. Asignar alimentos a animales");
                                System.out.println("3. Ver qué animales se alimentan de un determinado alimento.");
                                System.out.println("4. Eliminar un alimento.");
                                System.out.println("5. Crear fichero con la lista de alimentos disponibles");
                                System.out.println("6. Salir");
                                int opcion1 = Integer.parseInt(sc.nextLine());

                                switch (opcion1) {
                                    case 1:
                                        System.out.println("Introduzca el nombre del alimento: ");
                                        nomAli = sc.nextLine();

                                        try {
                                            codAli = alservice
                                                    .create(new Alimento(0, nomAli));
                                            System.out.printf("Alimento registrado correctamente (codAli: %d)\n",
                                                    codAli);
                                        } catch (SQLException e) {
                                            if (e.getErrorCode() == 1062) {
                                                System.out.println(
                                                        "Ya hay un alimento registrado con ese nombre,intentelo de nuevo con uno diferente.");
                                            }
                                        }
                                        break;

                                    case 2:
                                        listarAnimal(anservice);
                                        System.out.println("Ingrese el código del animal:");
                                        codAni = Integer.parseInt(sc.nextLine());

                                        listarAlimentos(alservice);
                                        System.out.println("Ingrese el código del alimento:");
                                        codAli = Integer.parseInt(sc.nextLine());

                                        String sql = String.format(
                                                "INSERT INTO come (codAni, codAli) VALUES (%d, %d)", codAni,
                                                codAli);

                                        try {
                                            int rowAffected = statement.executeUpdate(sql);
                                            if (rowAffected == 1) {
                                                System.out.println("Alimento asignado al animal correctamente.");
                                            } else {
                                                System.out.println("No se pudo asignar el alimento.");
                                            }
                                        } catch (SQLException e) {
                                            System.out.println("El alimento ya esta asignado a ese animal");
                                        }
                                        break;

                                    case 3:
                                        listarAlimentos(alservice);
                                        System.out.print("Ingrese el codigo del alimento: ");
                                        codAli = sc.nextInt();
                                        sc.nextLine();

                                        ArrayList<String> comen = comservice.comeAnimal(codAli);

                                        if (comen.isEmpty()) {
                                            System.out
                                                    .println(" No hay ningún animal que se alimente de ese alimento.");
                                        } else {
                                            System.out.println(
                                                    "Animales que comen el alimento:");
                                            for (String c : comen) {
                                                System.out.println(c);
                                            }
                                        }
                                        break;

                                    case 4:
                                        System.out.println("Elija el codigo del alimento a borrar");
                                        listarAlimentos(alservice);
                                        codAli = Integer.parseInt(sc.nextLine());
                                        try {
                                            alservice.delete(codAli);
                                            System.out.println("alimento eliminado correctamente");
                                        } catch (SQLException e) {
                                            System.out.println(e.getMessage());
                                        }
                                        break;

                                    case 5:
                                        System.out
                                                .println("Ingrese el nombre del archivo CSV (ejemplo: alimento.csv): ");
                                        alservice.exportToCSV(sc.nextLine());
                                        System.out.println("Archivo creado correctamente");
                                        break;
                                    case 6:
                                        submenusalir = true;
                                        break;

                                    default:
                                        break;
                                }
                            } catch (Exception e) {
                                System.out.println("error: " + e.getMessage());
                            }
                        }
                        break;

                    case 7:
                        System.out.println("Ingrese el nombre del archivo CSV a eliminar: ");
                        File carpeta = new File(".");

                        String[] archivos = carpeta.list();
                        if (archivos != null && archivos.length > 0) {
                            System.out.println("Archivos en el directorio actual:");
                            for (String archivo : archivos) {
                                System.out.println("- " + archivo);
                            }
                        } else {
                            System.out.println("El directorio está vacío.");
                        }
                        File file = new File(sc.nextLine());
                        if (file.exists()) {
                            file.delete();
                            System.out.println("El archivo ha sido eliminado correctamente.");
                        } else {
                            System.out.println("El archivo no existe.");
                        }
                        break;

                    case 8:
                        salir = true;
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                System.out.println("error: "+e.getMessage());
            }
        }
        sc.close();
    }
}