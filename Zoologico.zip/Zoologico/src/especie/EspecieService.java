package especie;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import CRUD.CRUD;

public class EspecieService implements CRUD<Especie>{

    Connection conn;
    public EspecieService(Connection conn){
        this.conn = conn;
    }

    public void exportToCSV(String file) throws Exception {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));
            ArrayList<Especie> especies = this.requestAll();
            for(Especie es:especies){
                bw.write(es.serialize()+"\n");
            }
            bw.close();
        } catch(IOException e){
            throw new Exception("Ocurrión un error de E/S "+ e.toString());
        } catch(SQLException e){
            throw new Exception("Ocurrión un error al acceder a la base de datos "+ e.toString());
        }catch (Exception e) {
            throw new Exception("Ocurrión un error "+ e.toString());
        } finally {
            if(bw!=null)
                bw.close();
        }
    }

    @Override
    public ArrayList<Especie> requestAll() throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        ArrayList<Especie> res= new ArrayList<Especie>();
        statement = this.conn.createStatement();   
        String sql = "SELECT codEsp, tipEsp, desEsp FROM especie";
        ResultSet querySet = statement.executeQuery(sql);
        while(querySet.next()) {
            Integer codEsp = querySet.getInt("codEsp");
            String tipEsp = querySet.getString("tipEsp");
            String desEsp = querySet.getString("desEsp");
            res.add(new Especie(codEsp, tipEsp, desEsp));
        } 
        statement.close();    
        return res;
    }

    public Especie requestByNom(String tipEsp) throws SQLException {
        Statement statement = null;
        Especie res = null;
        statement = this.conn.createStatement();    
        String sql = String.format("SELECT codEsp, tipEsp, desEsp FROM especie WHERE tipEsp='%s'", tipEsp);
        ResultSet querySet = statement.executeQuery(sql);
        if(querySet.next()) {
            Integer codEsp = querySet.getInt("codEsp");
            String desEsp = querySet.getString("desEsp");
            
            res = new Especie(codEsp, tipEsp, desEsp);
        }
        statement.close();    
        return res;
    }

    @Override
    public Integer create(Especie object) throws SQLException {
        // TODO Auto-generated method stub

        String sqlaux = String.format("INSERT INTO especie (tipEsp, desEsp) VALUES (?, ?)");
        PreparedStatement prepst = this.conn.prepareStatement(sqlaux, Statement.RETURN_GENERATED_KEYS);
        prepst.setString(1, object.getTipEsp());
        prepst.setString(2, object.getDesEsp());
        prepst.execute();
        ResultSet keys = prepst.getGeneratedKeys();
        if(keys.next()){
            Integer codEsp = keys.getInt(1);
                prepst.close();
                return codEsp;
        }
        else{
            throw new SQLException("Creating species failed, no rows affected.");
        }
        
    }

    @Override
    public boolean delete(Integer codEsp) throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("DELETE FROM especie WHERE codEsp=%d", codEsp);
        int res = statement.executeUpdate(sql);
        statement.close();
        return res==1;
    }
    
}
