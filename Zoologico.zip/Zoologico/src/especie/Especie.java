package especie;

public class Especie {
    Integer codEsp;
    String desEsp;
    String tipEsp;

    public Especie(Integer codEsp,String tipEsp, String desEsp) {
        this.codEsp = codEsp;
        this.desEsp = desEsp;
        this.tipEsp = tipEsp;
    }

    public Especie() {
        this(0,"","");
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return String.format("ID: %d, Tipo: %s, Descripcion: %s", this.codEsp, this.tipEsp,this.desEsp);
    }

    public String serialize() {
            return String.format("\"%d\";\"%s\";\"%s\"", codEsp, tipEsp != null ? tipEsp : "", desEsp != null ? desEsp : "");
        
    }

    public Integer getCodEsp() {
        return codEsp;
    }

    public void setCodEsp(Integer codEsp) {
        this.codEsp = codEsp;
    }

    public String getDesEsp() {
        return desEsp;
    }

    public void setDesEsp(String desEsp) {
        this.desEsp = desEsp;
    }

    public String getTipEsp() {
        return tipEsp;
    }

    public void setTipEsp(String tipEsp) {
        this.tipEsp = tipEsp;
    }

    
}
