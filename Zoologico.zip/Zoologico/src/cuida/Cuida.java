package cuida;

public class Cuida {
    private Integer codCui;
    private Integer codAni;
    
    public Cuida() {
        this(0,0);
    }

    public Cuida(Integer codCui, Integer codAni) {
        this.codCui = codCui;
        this.codAni = codAni;
    }

    @Override
    public String toString() {
        return String.format("codCui: %d, codAni: %d", this.codCui, this.codAni);
    }

    public Integer getCodCui() {
        return codCui;
    }

    public void setCodCui(Integer codCui) {
        this.codCui = codCui;
    }

    public Integer getCodAni() {
        return codAni;
    }

    public void setCodAni(Integer codAni) {
        this.codAni = codAni;
    }
}
