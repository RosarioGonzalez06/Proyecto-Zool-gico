package cuida;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class CuidaService {
    
    Connection conn;

    public CuidaService(Connection conn){
        this.conn = conn;
    }

    public ArrayList<String> cuidaAnimal(int codCui) throws Exception {
        ArrayList<String> animales = new ArrayList<>();
        String sql = "SELECT a.codAni, a.nomAni FROM animal a JOIN cuida c ON a.codAni = c.codAni WHERE c.codCui = ?";
        
        PreparedStatement prep = null;
        ResultSet res = null;

        try {
            prep = conn.prepareStatement(sql);
            prep.setInt(1, codCui);
            res = prep.executeQuery();

            while (res.next()) {
                int codAni = res.getInt("codAni");
                String nomAni = res.getString("nomAni");
                animales.add(codAni + " - " + nomAni);
            }
        } catch (Exception e) {
            throw new Exception("Error al obtener los animales: " + e.getMessage());
        }
        return animales;
    }
}
