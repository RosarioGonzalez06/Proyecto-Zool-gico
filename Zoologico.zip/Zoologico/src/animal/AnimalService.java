package animal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;

import CRUD.CRUD;

public class AnimalService implements CRUD<Animal>{

    public Connection conn;
    public AnimalService(Connection conn){
        this.conn = conn;
    }

    public void exportToCSV(String file) throws Exception {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));
            ArrayList<Animal> animales = this.requestAll();
            for(Animal an:animales){
                bw.write(an.serialize()+"\n");
            }
            bw.close();
        } catch(IOException e){
            throw new Exception("Ocurrión un error de E/S "+ e.toString());
        } catch(SQLException e){
            throw new Exception("Ocurrión un error al acceder a la base de datos "+ e.toString());
        }catch (Exception e) {
            throw new Exception("Ocurrión un error "+ e.toString());
        } finally {
            if(bw!=null)
                bw.close();
        }
    }

    @Override
    public ArrayList<Animal> requestAll() throws SQLException {
        // TODO Auto-generated method stub
        ArrayList<Animal> res = new ArrayList<Animal>();
        Statement statement = null;
        statement = this.conn.createStatement();   
        String sql = "SELECT codAni, nomAni, fecNac, sexAni, codEsp, codRec  FROM animal";
        ResultSet querySet = statement.executeQuery(sql);
        while(querySet.next()) {

            Integer codAni = querySet.getInt("codAni");
            String nomAni = querySet.getString("nomAni");
            Date fecNac = querySet.getDate("fecNac");
            String sexAniStr = querySet.getString("sexAni");
            Sexo sexAni = Sexo.valueOf(sexAniStr.toUpperCase());

            Integer codEsp = querySet.getInt("codEsp")==0?null:querySet.getInt("codEsp");
            Integer codRec = querySet.getInt("codRec")==0?null:querySet.getInt("codRec");

            res.add(new Animal(codAni, nomAni, fecNac, sexAni,codEsp,codRec));

        } 
        statement.close();

        return res;
    }

    public Animal requestByNom(String nomAni) throws SQLException {
        Statement statement = null;
        Animal res = null;
        statement = this.conn.createStatement();    
        String sql = String.format("SELECT codAni, nomAni, fecNac, sexAni, codEsp, codRec FROM animal WHERE nomAni='%s'", nomAni);
        ResultSet querySet = statement.executeQuery(sql);
        if(querySet.next()) {
            Integer codAni = querySet.getInt("codAni");
            Date fecNac = querySet.getDate("fecNac");
            String sexAniStr = querySet.getString("sexAni");
            Sexo sexAni = Sexo.valueOf(sexAniStr.toUpperCase());
            
            Integer codEsp = querySet.getInt("codEsp")==0?null:querySet.getInt("codEsp");
            Integer codRec = querySet.getInt("codRec")==0?null:querySet.getInt("codRec");
            res = new Animal(codAni, nomAni, fecNac,sexAni, codEsp,codRec);
        }
        statement.close();    
        return res;
    }

    @Override
    public Integer create(Animal object) throws SQLException {
        // TODO Auto-generated method stub
        String sqlaux = String.format("INSERT INTO animal (nomAni, fecNac, sexAni, codEsp, codRec) VALUES (?, ?, ?, ?, ?)");
        PreparedStatement prepst = this.conn.prepareStatement(sqlaux, Statement.RETURN_GENERATED_KEYS);
        prepst.setString(1, object.getNomAni());
        prepst.setDate(2, object.getFecNac());
        prepst.setString(3, object.getSexAni().name());
        if(object.getCodEsp()==null)
            prepst.setNull(4,Types.INTEGER);
        else
            prepst.setInt(4, object.getCodEsp());

        if(object.getCodRec()==null)
            prepst.setNull(5,Types.INTEGER);
        else
            prepst.setInt(5, object.getCodRec());
        prepst.execute();
        ResultSet keys = prepst.getGeneratedKeys();
        if(keys.next()){
            Integer codAni = keys.getInt(1);
                prepst.close();
                return codAni;
        }
        else{
            throw new SQLException("Creating animal failed, no rows affected.");
        }
        
    }

    public int update(Animal object) throws SQLException {
        Integer codAni = object.getCodAni();
        String nomAni = object.getNomAni();
        Date fecNac = object.getFecNac();
        Sexo sexAni= object.getSexAni();
        Integer codEsp = object.getCodEsp();
        Integer codRec = object.getCodRec();
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("UPDATE animal SET nomAni = '%s', fecNac = '%s', sexAni='%s', codEsp=%d, codRec=%d WHERE codAni=%d", nomAni, fecNac, sexAni,codEsp,codRec, codAni);
        int affectedRows = statement.executeUpdate(sql);
        statement.close();
        if (affectedRows == 0)
            throw new SQLException("Creating animal failed, no rows affected.");
        else
            return affectedRows;
    }

    @Override
    public boolean delete(Integer codAni) throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("DELETE FROM animal WHERE codAni=%d", codAni);
        int res = statement.executeUpdate(sql);
        statement.close();
        return res==1;
    }
    
}
