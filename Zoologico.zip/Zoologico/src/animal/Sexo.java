package animal;

public enum Sexo {
    M,F;
}
