package animal;

import java.sql.Date;

public class Animal {
    Integer codAni;
    Integer codEsp;
    Integer codRec;
    Date fecNac;
    String nomAni;
    Sexo sexAni;
    
    public Animal(Integer codAni,String nomAni,Date fecNac,Sexo sexAni, Integer codEsp, Integer codRec) {
        this.codAni = codAni;
        this.codEsp = codEsp;
        this.codRec = codRec;
        this.fecNac = fecNac;
        this.nomAni = nomAni;
        this.sexAni = sexAni;
    }

    public Animal() {
        this(0,"",null,null,null,null);
    }

    public String serialize() {
            return String.format("\"%d\";\"%s\";\"%s\";\"%s\";\"%d\";\"%d\"",codAni, nomAni != null ? nomAni : "",fecNac != null ? new java.text.SimpleDateFormat("dd-MM-yyyy").format(fecNac) : "",sexAni != null ? sexAni.name() : "", codEsp, codRec);
    }

    @Override
    public String toString() {
        return String.format("ID: %d, Nombre: %s, Fecha de nacimiento: %s, Sexo: %s, codEsp: %s, codRec: %s",this.codAni, this.nomAni, this.fecNac.toString() ,this.sexAni.toString(),this.codEsp,this.codRec);
    }
    

    public Integer getCodAni() {
        return codAni;
    }

    public void setCodAni(Integer codAni) {
        this.codAni = codAni;
    }

    public Integer getCodEsp() {
        return codEsp;
    }

    public void setCodEsp(Integer codEsp) {
        this.codEsp = codEsp;
    }

    public Integer getCodRec() {
        return codRec;
    }

    public void setCodRec(Integer codRec) {
        this.codRec = codRec;
    }

    public Date getFecNac() {
        return fecNac;
    }

    public void setFecNac(Date fecNac) {
        this.fecNac = fecNac;
    }

    public String getNomAni() {
        return nomAni;
    }

    public void setNomAni(String nomAni) {
        this.nomAni = nomAni;
    }

    public Sexo getSexAni() {
        return sexAni;
    }

    public void setSexAni(Sexo sexAni) {
        this.sexAni = sexAni;
    }
}
