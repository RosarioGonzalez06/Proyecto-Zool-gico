package recinto;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import CRUD.CRUD;

public class RecintoService implements CRUD<Recinto> {

    Connection conn;
    public RecintoService(Connection conn){
        this.conn = conn;
    }

    public void exportToCSV(String file) throws Exception {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));
            ArrayList<Recinto> recintos = this.requestAll();
            for(Recinto re:recintos){
                bw.write(re.serialize()+"\n");
            }
            bw.close();
        } catch(IOException e){
            throw new Exception("Ocurrión un error de E/S "+ e.toString());
        } catch(SQLException e){
            throw new Exception("Ocurrión un error al acceder a la base de datos "+ e.toString());
        }catch (Exception e) {
            throw new Exception("Ocurrión un error "+ e.toString());
        } finally {
            if(bw!=null)
                bw.close();
        }
    }

    @Override
    public ArrayList<Recinto> requestAll() throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        ArrayList<Recinto> res = new ArrayList<Recinto>();
        statement = this.conn.createStatement();   
        String sql = "SELECT codRec, nomRec, desRec FROM recinto";
        ResultSet querySet = statement.executeQuery(sql);
        while(querySet.next()) {
            Integer codRec = querySet.getInt("codRec");
            String nomRec = querySet.getString("nomRec");
            String desRec = querySet.getString("desRec");
            res.add(new Recinto(codRec, nomRec, desRec));
        } 
        statement.close();    
        return res;
    }

    public Recinto requestByNom(String nomRec) throws SQLException {
        Statement statement = null;
        Recinto res = null;
        statement = this.conn.createStatement();    
        String sql = String.format("SELECT codRec, nomRec, desRec FROM recinto WHERE nomRec='%s'", nomRec);
        ResultSet querySet = statement.executeQuery(sql);
        if(querySet.next()) {
            Integer codRec = querySet.getInt("codRec");
            String desRec = querySet.getString("desRec");
            
            res = new Recinto(codRec, nomRec, desRec);
        }
        statement.close();    
        return res;
    }

    @Override
    public Integer create(Recinto object) throws SQLException {
        // TODO Auto-generated method stub

        String sqlaux = String.format("INSERT INTO recinto (nomRec, desRec) VALUES (?, ?)");
        
        PreparedStatement prepst = this.conn.prepareStatement(sqlaux, Statement.RETURN_GENERATED_KEYS);
        prepst.setString(1, object.getnomRec());
        prepst.setString(2, object.getDesRec());
        prepst.execute();
        ResultSet keys = prepst.getGeneratedKeys();
        if(keys.next()){
            Integer codRec = keys.getInt(1);
                prepst.close();
                return codRec;
        }
        else{
            throw new SQLException("Creating enclosure failed, no rows affected.");
        }
    }

    @Override
    public boolean delete(Integer codRec) throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("DELETE FROM recinto WHERE codRec=%d", codRec);
        int res = statement.executeUpdate(sql);
        statement.close();
        return res==1;
    }
    
}
