package recinto;

import recinto.Recinto;

public class Recinto {
    
    Integer codRec;
    String desRec;
    String nomRec;

    public Recinto(Integer codRec, String nomRec,String desRec) {
        this.codRec = codRec;
        this.desRec = desRec;
        this.nomRec = nomRec;
    }

    public Recinto() {
        this(0,"","");
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return String.format("ID: %d, Nombre: %s, Descripcion: %s", this.codRec, this.nomRec,this.desRec);
    }

    public String serialize() {
            return String.format("\"%d\";\"%s\";\"%s\"", codRec, nomRec != null ? nomRec : "", desRec != null ? desRec : "");
        
    }

    public Integer getCodRec() {
        return codRec;
    }

    public void setCodRec(Integer codRec) {
        this.codRec = codRec;
    }

    public String getDesRec() {
        return desRec;
    }

    public void setDesRec(String desRec) {
        this.desRec = desRec;
    }

    public String getnomRec() {
        return nomRec;
    }

    public void setnomRec(String nomRec) {
        this.nomRec = nomRec;
    }

}
