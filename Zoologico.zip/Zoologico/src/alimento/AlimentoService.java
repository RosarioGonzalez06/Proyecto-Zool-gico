package alimento;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import CRUD.CRUD;

public class AlimentoService implements CRUD<Alimento>{

    Connection conn;
    public AlimentoService(Connection conn){
        this.conn = conn;
    }

    public void exportToCSV(String file) throws Exception {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(file, StandardCharsets.UTF_8));
            ArrayList<Alimento> alimentos = this.requestAll();
            for(Alimento al:alimentos){
                bw.write(al.serialize()+"\n");
            }
            bw.close();
        } catch(IOException e){
            throw new Exception("Ocurrión un error de E/S "+ e.toString());
        } catch(SQLException e){
            throw new Exception("Ocurrión un error al acceder a la base de datos "+ e.toString());
        }catch (Exception e) {
            throw new Exception("Ocurrión un error "+ e.toString());
        } finally {
            if(bw!=null)
                bw.close();
        }
        
    }
    

    @Override
    public ArrayList<Alimento> requestAll() throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        ArrayList<Alimento> res = new ArrayList<Alimento>();
        statement = this.conn.createStatement();   
        String sql = "SELECT codAli, nomAli FROM alimento";
        ResultSet querySet = statement.executeQuery(sql);
        while(querySet.next()) {
            int codAli = querySet.getInt("codAli");;
            String nomAli = querySet.getString("nomAli");
            res.add(new Alimento(codAli, nomAli));
        } 
        statement.close();    
        
        return res;
    }

    @Override
    public Integer create(Alimento object) throws SQLException {
        // TODO Auto-generated method stub
        String sqlaux = String.format("INSERT INTO alimento (nomAli) VALUES (?)");
        PreparedStatement prepst = this.conn.prepareStatement(sqlaux, Statement.RETURN_GENERATED_KEYS);
        prepst.setString(1, object.getNomAli());
        prepst.execute();
        ResultSet keys = prepst.getGeneratedKeys();
        if(keys.next()){
            Integer codAli = keys.getInt(1);
                prepst.close();
                return codAli;
        }
        else{
            throw new SQLException("Creating food failed, no rows affected.");
        }
    }

    @Override
    public boolean delete(Integer codAli) throws SQLException {
        // TODO Auto-generated method stub
        Statement statement = null;
        statement = this.conn.createStatement();    
        String sql = String.format("DELETE FROM alimento WHERE codAli=%d", codAli);
        int res = statement.executeUpdate(sql);
        statement.close();
        return res==1;
    }
    
}


