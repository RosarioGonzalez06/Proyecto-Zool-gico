package alimento;

public class Alimento {
    Integer codAli;
    String nomAli;

    public Alimento(Integer codAli, String nomAli) {
        this.codAli = codAli;
        this.nomAli = nomAli;
    }

    public Alimento() {
        this(0,"");
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return String.format("ID: %d, nomAli: %s", this.codAli, this.nomAli);
    }

    public String serialize() {
        return String.format("\"%d\";\"%s\"", this.codAli, this.nomAli != null ? this.nomAli : "");
    }

    public int getId() {
        return codAli;
    }

    public void setId(int id) {
        this.codAli = id;
    }

    public String getNomAli() {
        return nomAli;
    }

    public void setNomAli(String nomAli) {
        this.nomAli = nomAli;
    }
    
    
}