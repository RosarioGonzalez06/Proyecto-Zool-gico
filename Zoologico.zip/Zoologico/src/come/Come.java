package come;

public class Come {
    protected Integer codAli; 
    private Integer codAni; 

    public Come() {
        this(0,0);
    }

    public Come(Integer codAli, Integer codAni) {
        this.codAli = codAli;
        this.codAni = codAni;
    }

    @Override
    public String toString() {
        return String.format("codAli: %d, codAni: %d", this.codAli, this.codAni);
    }

    public Integer getCodAli() {
        return codAli;
    }

    public void setCodAli(Integer codAli) {
        this.codAli = codAli;
    }

    public Integer getCodAni() {
        return codAni;
    }

    public void setCodAni(Integer codAni) {
        this.codAni = codAni;
    }

    
}
