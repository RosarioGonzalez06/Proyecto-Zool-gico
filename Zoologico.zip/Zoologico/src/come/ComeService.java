package come;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ComeService {
    
    Connection conn;
    public ComeService(Connection conn){
        this.conn = conn;
    }

        public ArrayList<String> comeAnimal(int codAli) throws Exception {
        ArrayList<String> animales = new ArrayList<>();
        String sql = "SELECT a.codAni, a.nomAni FROM animal a JOIN come c ON a.codAni = c.codAni WHERE c.codAli = ?";
        PreparedStatement prep = null;
        ResultSet res = null;

        try {
            prep = conn.prepareStatement(sql);
            prep.setInt(1, codAli);
            res = prep.executeQuery();

            while (res.next()) {
                int codAni = res.getInt("codAni");
                String nomAni = res.getString("nomAni");
                animales.add(codAni + " - " + nomAni);
            }
        } catch (Exception e) {
            throw new Exception("Error al obtener los animales: " + e.getMessage());
        }
        return animales;
    }
}
